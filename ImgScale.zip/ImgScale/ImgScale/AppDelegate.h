//
//  AppDelegate.h
//  ImgScale
//
//  Created by BO on 17/2/20.
//  Copyright © 2017年 xsqBo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

